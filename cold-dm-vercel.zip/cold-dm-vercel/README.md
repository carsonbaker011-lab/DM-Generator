# Cold DM Generator — Vercel Deploy

## Folder Structure
```
cold-dm-vercel/
├── api/
│   └── generate.js     ← serverless backend (holds your API key)
├── public/
│   └── index.html      ← the full app
└── vercel.json         ← routing config
```

## Deploy Steps

### 1. Install Vercel CLI (if you haven't)
```bash
npm install -g vercel
```

### 2. Go into the project folder
```bash
cd cold-dm-vercel
```

### 3. Deploy
```bash
vercel
```
Follow the prompts — choose your account, create a new project, accept defaults.

### 4. Add your Anthropic API key
After first deploy, go to:
**Vercel Dashboard → Your Project → Settings → Environment Variables**

Add:
- Key:   `ANTHROPIC_API_KEY`
- Value: `sk-ant-...` (your key from console.anthropic.com)
- Environment: Production + Preview + Development ✓

### 5. Redeploy to apply the env variable
```bash
vercel --prod
```

That's it — your app is live! 🚀

## Get an Anthropic API Key
1. Go to https://console.anthropic.com
2. Sign up / log in
3. Go to API Keys → Create Key
4. Copy it and paste into Vercel env variable

New accounts get $5 free credit (~300–500 generations).

## Costs
- Hosting: Free (Vercel hobby plan)
- AI: ~$0.01–0.03 per generation (Anthropic pay-per-use)
